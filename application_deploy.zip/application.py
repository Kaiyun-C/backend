'''
Date: 28/08/2022
Author: Kaiyun Chen
'''
# import requests
# import base64
from flask import Flask, jsonify, request
from flask_cors import CORS
import logging

# from flask_sqlalchemy import SQLAlchemy
import pandas as pd
import pickle
# import chart_studio
# import plotly.graph_objects as go
# import chart_studio.plotly as py
# import plotly.express as px
# import random
import json
# import pymysql
# pymysql.install_as_MySQLdb()


app = application = Flask(__name__)
CORS(application)


@application.route("/add", methods=["POST"], strict_slashes=False)
def add_articles():
    height = float(request.json['height'])
    weight = float(request.json['weight'])

    bmi = weight/((height/100)**2)

    return jsonify({"bmi": bmi})


@application.route("/predict", methods=["POST"])
def diabetes_predict():
    filename = 'finalized_model.sav'
    loaded_model = pickle.load(open(filename, 'rb'))

    # drop when get value from front-end
    # lst = ['yes', 'yes', 'no', 'no', 'yes', 'yes']
    # values = json.dumps(lst)
    # values = json.loads(values)
    # values = [1 if i == 'yes' else 0 for i in values] # [1,1,0,0,1,1]
    # values = '1243'

    feature_name = ['have_prediabetes', 'family_history', 'overweight', 'poor_diet', 'lack_physical_activity',
                    'high_blood_sugar']
    # get value from front-end
    values = request.json['answer']

    if type(values) == str:
        values = json.loads(values)
        values = [1 if i == 'Yes' else 0 for i in values]
        test_data = dict(zip(feature_name, values))
        test_df = pd.DataFrame([test_data])
        pred_result = loaded_model.predict_proba(test_df)
        get_diabetes = round(pred_result[0][1], 2)
        return jsonify({"diabetes prediction": get_diabetes})
    elif type(values) == list:
        values = [1 if i == 'Yes' else 0 for i in values]
        test_data = dict(zip(feature_name, values))
        test_df = pd.DataFrame([test_data])
        pred_result = loaded_model.predict_proba(test_df)
        get_diabetes = round(pred_result[0][1], 2)
        return jsonify({"diabetes prediction": get_diabetes})


@application.route("/", methods=["GET"])
def index():

    return jsonify({"HELLO": "WORLD3"})


if __name__ == "__main__":
    application.run()
